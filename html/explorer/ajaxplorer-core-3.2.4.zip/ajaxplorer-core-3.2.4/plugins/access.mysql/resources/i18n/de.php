<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2008 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//	german translation: Axel Otterstätter <axel.otterstaetter@googlemail.com>
// 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1" => "Tabelle erstellen",
"2" => "SQL Abfrage hier eingeben",
"3"	=> "Suchen",
"4"	=> "Löschen"
);
?>
