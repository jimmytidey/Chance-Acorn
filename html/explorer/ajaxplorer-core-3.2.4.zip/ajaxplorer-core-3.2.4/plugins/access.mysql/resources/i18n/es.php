<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2008 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1" => "Crear Tabla",
"2" => "Escriba sy consulta SQL aquí",
"3"	=> "Consultar",
"4"	=> "Limpiar"
);
?>
