<?php
$mess = array(
"1" => "Klassen und Schnittstellen",
"2" => "Eigenschaften und Methoden",
"3" => "Quelltext"
); 
?>
