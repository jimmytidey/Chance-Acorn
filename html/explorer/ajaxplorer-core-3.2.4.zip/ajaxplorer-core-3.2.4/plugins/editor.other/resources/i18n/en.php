<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2010 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1" => "Choose other...",
"2" => "Choose another editor",
"3" => "Select another editor to open this file",
"4" => "Warning, these editors do not declare to be supporting this file type, their behaviour maybe unpredictable!",
); 
?>