<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2010 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1" => "External window",
"2" => "External browser window",
"3" => "Opening file in external window, please wait, this window should close automatically.",
); 
?>
