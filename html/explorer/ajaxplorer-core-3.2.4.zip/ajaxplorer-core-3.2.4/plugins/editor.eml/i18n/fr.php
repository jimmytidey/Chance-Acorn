<?php 
$mess = array(
"name" => "Editeur Email",
"title" => "Editeur Email",
"1" => "De",
"2" => "A",
"3" => "Sujet",
"4"	=> "Date",
"5" => "Attachements",
"6" => "Télécharger EML",
"7" => "L'attachement %s a été copié avec succès dans %s",
"8" => "Impossible d'ouvrir le fichier de destination!",
"9" => "Impossible de trouver l'attachement",
"10" => "Télécharger ",
"11" => "Copier l'attachement sur le serveur",
"12" => "Cc",
);
?>