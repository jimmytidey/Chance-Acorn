<?php

$mess = array(
"1" => "Versiones", 
"11" => "Registro SVN de la carpeta actual", 
"2" => "Registro de selección",
"21" => "Registro SVN del archivo o carpeta seleccionada",
"3" => "Cambiar a revisión",
);

?>
