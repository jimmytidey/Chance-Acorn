<?php

$mess = array(
"1" => "Versions", 
"11" => "SVN Log of current folder", 
"2" => "Selection Log",
"21" => "SVN Log of selected file or folder",
"3" => "Switch to revision",
);

?>