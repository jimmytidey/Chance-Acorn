<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2008 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// Slovenian translation: April 21 2011 by Vladimir Bohinc (vladimir.bohinc@gmail.com)
// 
//---------------------------------------------------------------------------------------------------
$mess = array(
"1" => "Različice", 
"11" => "SVN dnevnik trenutne mape", 
"2" => "SVN dnevnik",
"21" => "SVN dnevnik izbrane datoteke/mape",
"3" => "Preklopi na to različico",
);
?>