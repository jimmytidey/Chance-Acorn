<?php

$mess = array(
"1" => "Exif GeoLocation", 
"2" => "Locate", 
);

?>