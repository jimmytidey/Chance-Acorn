<?php

$mess = array(
"1" => "GeoUbicación Exif", 
"2" => "Ubicar", 
);

?>
