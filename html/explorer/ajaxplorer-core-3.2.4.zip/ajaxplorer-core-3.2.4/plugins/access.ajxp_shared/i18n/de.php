<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2010 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1" => "Gemeinsame Benutzer",
"2" => "Gemeinsame Repositories",
"3" => "Öffentliche Dateien",
"4"	=> "Dateipfad",
"5"	=> "Repository",
"6"	=> "Passwort",
"7"	=> "Ablauf",
"8" => "Elemente",
"9" => "Verknüpfte Benutzer",
"10"=> "Verknüpfte Repositories",
"11"=> "Sollen die ausgewählten Elemente wirklich gelöscht werden?",
"12"=> "Die Berechtigung zum Löschen dieses Elements fehlt.",
"13"=> "Öffentliche Dateien erfolgreich entfernt.",
"14"=> "Integrität",
"15"=> "OK",
"16"=> "Fehlerhaft",
"17"=> "Download URL",
"18"=> "URL kopieren",
"19"=> "URL zum Senden per E-Mail kopieren.",
"20"=> "Downloads",
"21"=> "Ja",
"22"=> "Nein",
"23"=> "%s Dateien erfolgreich gelöscht.",
"24"=> "Nichts zum Entfernen.",
"25"=> "Entfernen abgelaufen",
"26"=> "Ausgelaufene freigegebene Dateien entfernen.",
"27"=> "Besitzer",
"28"=> "Dateien zum direkten Download mit oder ohne Passwortschutz freigegeben.",
"29"=> "Repositories von Benutzern übertragen.",
"30"=> "Erzeugte Benutzer zum Zugriff auf die übertragenen Repositories.",
"31"=> "Beschreibung",
"32"=> "Reset",
"33"=> "Download-Zähler zurücksetzen",
); 
?>
