<?php

$mess = array(
"1" => "Exif Reader", 
"2" => "Display Exif data", 
);

?>