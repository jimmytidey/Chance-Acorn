<?php

$mess=array(
"1" => "OpenLayers Karte",
"2" => "Filter",
"3" => "Position",
"4" => "Layers",
"5" => "Antialias",
"6" => "Format",
"7" => "Styles",
"8" => "Filter",
"9" => "Suchen",
"10" => "Löschen",
)

?>
