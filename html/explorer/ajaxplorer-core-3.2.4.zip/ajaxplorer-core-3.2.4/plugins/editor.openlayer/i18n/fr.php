<?php

$mess=array(
"1" => "Carte OpenLayers",
"2" => "Filtres",
"3" => "Position",
"4" => "Calques",
"5" => "Antialias",
"6" => "Format",
"7" => "Styles",
"8" => "Filtre",
"9" => "Chercher",
"10" => "Effacer",
)

?>