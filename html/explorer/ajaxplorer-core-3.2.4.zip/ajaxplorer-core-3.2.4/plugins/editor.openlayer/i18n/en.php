<?php

$mess=array(
"1" => "OpenLayers Map",
"2" => "Filter",
"3" => "Position",
"4" => "Layers",
"5" => "Antialias",
"6" => "Format",
"7" => "Styles",
"8" => "Filter",
"9" => "Search",
"10" => "Clear",
)

?>