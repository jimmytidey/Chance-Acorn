<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2010 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1" => "Meta Données",
"2" => "Pas d'étiquette",
"3" => "Retirer la notation",
"4" => "Faible",
"5" => "A faire",
"6" => "Personel",
"7" => "Travail", 
"8" => "Important"
);
?>
