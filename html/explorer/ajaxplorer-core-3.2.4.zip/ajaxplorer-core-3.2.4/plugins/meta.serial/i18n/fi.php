<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2010 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//	Finnish translation by Aleksi Postari
//	aleksi (at) postari.net
//	Last update: 07.09.2010
// 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1" => "Tiedoston metatiedot",
"2" => "Ei nimeä",
"3" => "Poista luokitus",
"4" => "Pieni",
"5" => "Todo",
"6" => "Henkilökohtainen",
"7" => "Työ", 
"8" => "Tärkeä"
);
?>
