<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2010 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// spanish translation: Ion Rey Bakaikoa <ionrei@gmail.com>, 2010 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1" => "Etiquetas",
"2" => "Sin etiqueta",
"3" => "Sin valorar",
"4" => "Poca importancia",
"5" => "Pendiente",
"6" => "A revisar",
"7" => "Importante", 
"8" => "Urgente"
);
?>
