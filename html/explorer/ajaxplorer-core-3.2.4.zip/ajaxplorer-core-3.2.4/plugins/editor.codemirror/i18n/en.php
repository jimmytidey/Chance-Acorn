<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2010 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1"	=> "Source Editor",
"2"	=> "CodeMirror Syntax Highlighter",
"3" => "Wrapping",
"3b"=> "Toggle lines wrapping",
"4" => "Numbers",
"5" => "Toggle lines numbers",
"6"	=> "Jump to line",
"7" => "Undo",
"8"	=> "Redo",
"9"	=> "Text Search",
"10" => "Indent size"
);

?>