<?php
//---------------------------------------------------------------------------------------------------
//							
//	AjaXplorer
//	
//	Copyright 2007-2010 Charles du Jeu - LGPL
//  www.Ajaxplorer.info
//
//  Reference dictionnary for translations
// 
//---------------------------------------------------------------------------------------------------

$mess=array(
"1"	=> "Quelltext Editor",
"2"	=> "CodeMirror Syntax Highlighter",
"3"   => "Umbruch",
"3b"  => "Wechsel des Zeilenumbruchs",
"4"   => "Nummern",
"5"   => "Wechsel der Zeilennummern",
"6"	=> "Springe in Zeile",
"7"   => "Rückgängig",
"8"	=> "Wiederherstellen",
"9"	=> "Textsuche",
"10"  => "Zeileneinzug"
);

?>
